#pragma once

// ----------------------------------------------------------------------------
// Battery: read the divider, recover cell voltage, map to a LiPo % curve.
// ----------------------------------------------------------------------------

// Average several ADC reads and convert back to the true cell voltage.
float readBatteryVolts() {
  uint32_t accum_mV = 0;
  for (int i = 0; i < BATT_SAMPLES; i++) {
    accum_mV += analogReadMilliVolts(PIN_BATT);
  }
  float pin_mV = (float)accum_mV / (float)BATT_SAMPLES;
  return (pin_mV / 1000.0f) * BATT_DIVIDER * BATT_CAL; // volts at the cell
}

// Resting-discharge curve for a 1S LiPo. Piecewise-linear between table points.
// Voltage is under light load; the EMA smooths out PWM-induced rail dips.
uint8_t voltageToPercent(float v) {
  static const float vTab[] = {3.30f, 3.50f, 3.61f, 3.69f, 3.71f, 3.73f, 3.75f,
                               3.77f, 3.79f, 3.80f, 3.82f, 3.84f, 3.87f, 3.91f,
                               3.95f, 3.98f, 4.02f, 4.08f, 4.11f, 4.15f, 4.20f};
  static const float pTab[] = {0,  5,  10, 15, 20, 25, 30, 35, 40, 45, 50,
                               55, 60, 65, 70, 75, 80, 85, 90, 95, 100};
  const int n = sizeof(vTab) / sizeof(vTab[0]);

  if (v <= vTab[0])
    return 0;
  if (v >= vTab[n - 1])
    return 100;
  for (int i = 0; i < n - 1; i++) {
    if (v < vTab[i + 1]) {
      float frac = (v - vTab[i]) / (vTab[i + 1] - vTab[i]);
      return (uint8_t)round(pTab[i] + frac * (pTab[i + 1] - pTab[i]));
    }
  }
  return 100;
}

// Measure, smooth, recompute percent, and push a BLE notify if connected.
void updateBattery() {
  if (!BATTERY_SENSE_ENABLED)
    return; // Empty BLE value means unavailable; no floating ADC reads.
  float v = readBatteryVolts();
  // Initialize or update the exponential moving average (alpha = 0.25).
  battVoltsEMA =
      (battVoltsEMA < 0.0f) ? v : (battVoltsEMA + 0.25f * (v - battVoltsEMA));
  battPercent = voltageToPercent(battVoltsEMA);

  if (pCharBatt != nullptr) {
    // Pack [percent, mV_hi, mV_lo]. Clamp mV to a uint16 so the cast is safe.
    long mV = lround(battVoltsEMA * 1000.0f);
    if (mV < 0)
      mV = 0;
    if (mV > 65535)
      mV = 65535;
    uint8_t payload[3] = {battPercent, (uint8_t)(mV >> 8),
                          (uint8_t)(mV & 0xFF)};
    pCharBatt->setValue(payload, 3);
    if (deviceConnected)
      pCharBatt->notify();
  }
  Serial.printf("Battery: %.3f V (cell) -> %u%%\n", battVoltsEMA, battPercent);
}
