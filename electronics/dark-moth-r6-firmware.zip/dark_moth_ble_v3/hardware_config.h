#pragma once
#include <Arduino.h>

// R6 carrier ONLY: P-MOSFET latch, regulated 5 V, isolated active-LOW button.
// Do not flash this revision onto the historical R5 divider/button circuit.
constexpr const char *HARDWARE_REVISION = "R6";
#if defined(CONFIG_IDF_TARGET_ESP32C3)
constexpr int PINS[5] = {5, 6, 7, 10, 20}; // G, R, B, WW, CW
constexpr int PIN_HOLD = 3;
constexpr int PIN_BTN_SENSE = 4;
constexpr const char *BOARD_NAME = "ESP32-C3";
#elif defined(CONFIG_IDF_TARGET_ESP32S3)
constexpr int PINS[5] = {5, 4, 6, 10, 11};
constexpr int PIN_HOLD = 9;
constexpr int PIN_BTN_SENSE = 8;
constexpr const char *BOARD_NAME = "ESP32-S3";
#else
#error "Only the documented C3 and S3 pin maps are supported."
#endif
constexpr const char *NAMES[5] = {"Green", "Red", "Blue", "Warm White",
                                  "Cool White"};
constexpr int PWM_FREQ = 2000;
constexpr int PWM_RES = 14;
// Retained software ceiling; optical minimum pulse width is unmeasured on R6.
constexpr long MAXD = 16380;
constexpr uint32_t IDLE_OFF_MS = 5UL * 60UL * 1000UL;

// No battery ADC is fitted on R6. An always-live battery divider is prohibited:
// it can feed an unpowered MCU input. BLE battery value remains empty.
constexpr bool BATTERY_SENSE_ENABLED = false;
constexpr int PIN_BATT = 1;
constexpr float BATT_DIVIDER = 2.0f;
constexpr float BATT_CAL = 1.0f;
constexpr int BATT_SAMPLES = 16;
constexpr uint32_t BATT_INTERVAL_MS = 5000;
