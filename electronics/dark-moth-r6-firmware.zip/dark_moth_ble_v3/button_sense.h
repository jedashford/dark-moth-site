#pragma once
#include <stdint.h>

// Hardware-independent R6 gesture logic. Consume the cold-start press
// completely.
class ButtonGesture {
public:
  enum Event { None, ToggleLight, ArmShutdown, Shutdown };
  static constexpr uint32_t DebounceMs = 30;
  static constexpr uint32_t ShortTapMs = 500;
  static constexpr uint32_t LongPressMs = 2000;

  void reset(uint32_t now, bool pressed) {
    raw_ = stable_ = pressed;
    changeAt_ = pressedAt_ = now;
    waitingForRelease_ = true;
    armed_ = false;
  }

  Event update(uint32_t now, bool pressed) {
    if (pressed != raw_) {
      raw_ = pressed;
      changeAt_ = now;
    }
    if (now - changeAt_ < DebounceMs)
      return None;
    if (waitingForRelease_) {
      stable_ = raw_;
      if (!stable_)
        waitingForRelease_ = false;
      return None;
    }
    if (raw_ != stable_) {
      stable_ = raw_;
      if (stable_) {
        pressedAt_ = now;
        armed_ = false;
      } else {
        const uint32_t held = now - pressedAt_;
        if (armed_ || held >= LongPressMs)
          return Shutdown;
        if (held <= ShortTapMs)
          return ToggleLight;
      }
    }
    if (stable_ && !armed_ && now - pressedAt_ >= LongPressMs) {
      armed_ = true;
      return ArmShutdown;
    }
    return None;
  }

  bool pressed() const { return stable_; }

private:
  bool raw_ = false;
  bool stable_ = false;
  bool waitingForRelease_ = true;
  bool armed_ = false;
  uint32_t changeAt_ = 0;
  uint32_t pressedAt_ = 0;
};
