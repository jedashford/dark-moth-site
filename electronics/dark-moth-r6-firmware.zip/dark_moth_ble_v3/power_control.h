#pragma once

ButtonGesture buttonGesture;

void initializePowerHardware() {
  pinMode(PIN_HOLD, OUTPUT);
  digitalWrite(PIN_HOLD, HIGH);
  // QSN open collector plus the external 10k pull-up to switched ESP 3V3.
  pinMode(PIN_BTN_SENSE, INPUT_PULLUP);
  buttonGesture.reset(millis(), digitalRead(PIN_BTN_SENSE) == LOW);
}

bool lightIsOff() {
  if (sysPower == 0)
    return true;
  for (int i = 0; i < 5; i++)
    if (targetDuties[i] > 0)
      return false;
  return true;
}

void ledFeedbackBlink() {
  const int pin = PINS[1];
  if (attached[1]) {
    ledcDetach(pin);
    attached[1] = false;
  }
  pinMode(pin, OUTPUT);
  for (int k = 0; k < 2; k++) {
    digitalWrite(pin, HIGH);
    delay(60);
    digitalWrite(pin, LOW);
    delay(80);
  }
  applyDuties(); // Restore channels even when the ramp has no pending change.
}

void powerOff(const char *reason) {
  Serial.printf("[R6 power off] %s\n", reason);
  sysPower = 0;
  manualMode = false;
  for (int i = 0; i < 5; i++)
    targetDuties[i] = currentDuties[i] = 0;
  applyDuties();
  // Never restore HOLD on a timer: a slow rail collapse must remain off.
  digitalWrite(PIN_HOLD, LOW);
  // USB service power can keep the MCU alive; reset after servicing to restart.
  while (true)
    delay(10);
}

void pollButton() {
  const uint32_t now = millis();
  const auto event =
      buttonGesture.update(now, digitalRead(PIN_BTN_SENSE) == LOW);
  if (buttonGesture.pressed())
    lastActivityMs = now;
  switch (event) {
  case ButtonGesture::ToggleLight:
    sysPower = sysPower ? 0 : 1;
    manualMode = false;
    updateLight();
    break;
  case ButtonGesture::ArmShutdown:
    ledFeedbackBlink();
    break;
  case ButtonGesture::Shutdown:
    // START bypasses firmware HOLD while pressed, so shut down on release.
    powerOff("long press released");
    break;
  case ButtonGesture::None:
    break;
  }
}

void checkInactivity() {
  if (!lightIsOff() || deviceConnected || buttonGesture.pressed())
    return;
  if (millis() - lastActivityMs >= IDLE_OFF_MS)
    powerOff("5 minutes idle with light off");
}
