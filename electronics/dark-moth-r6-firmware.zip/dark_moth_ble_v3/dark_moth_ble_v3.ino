// Dark Moth R6 prototype: Yuji 12 V RGBWW, MOSFET latch, regulated ESP supply.
// Only use the R6 carrier wiring. Hold the side button until the controller
// starts; its first release is consumed. Subsequent taps toggle light, a 2 s
// hold followed by release shuts down. Connect the UMLIFE charging USB only
// after complete shutdown; unplug USB before turning on. No automatic charger
// detection or power sharing is implemented. A hardware voltage supervisor
// controls the low-battery latch cutoff. Firmware compilation does not qualify
// battery, thermal or optical performance. White mixing is a nominal mired
// crossfade, not measured CCT calibration.
//
// BLE GATT Specification:
//   Service UUID:         E0010000-4B2E-74CA-2C92-41CB5AD2D9BD
//   Char Power (W/R):     E0010001-4B2E-74CA-2C92-41CB5AD2D9BD (1 byte:
//   0x00/0x01) Char Brightness(W/R): E0010002-4B2E-74CA-2C92-41CB5AD2D9BD (1
//   byte: 0x00-0xFF) Char CCT (W/R):       E0010003-4B2E-74CA-2C92-41CB5AD2D9BD
//   (2 bytes: Kelvin) Char RGB (W/R): E0010004-4B2E-74CA-2C92-41CB5AD2D9BD (3
//   bytes: R, G, B) Char Mode (W/R):      E0010005-4B2E-74CA-2C92-41CB5AD2D9BD
//   (1 byte: 0x00=CCT, 0x01=RGB) Char Battery(R/N):
//   E0010006-4B2E-74CA-2C92-41CB5AD2D9BD (3 bytes: percent, mV_hi, mV_lo)
//                         Byte 0 = charge percent (0-100). Bytes 1-2 = cell
//                         millivolts (big-endian uint16). A client that only
//                         reads byte 0 still works — voltage is appended, not
//                         repositioned.
// ============================================================================

#include "button_sense.h"
#include <Arduino.h>
#include <BLE2902.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

#include "hardware_config.h"

// Active state
long targetDuties[5] = {0, 0, 0, 0, 0};
long currentDuties[5] = {0, 0, 0, 0, 0};
bool attached[5] = {false, false, false, false, false};

// Control variables (BLE state)
uint8_t sysPower = 0;      // 0 = Off, 1 = On (Starts OFF by default)
uint8_t brightness8 = 127; // 0 - 255 (defaults to 50%)
uint16_t cctTemp = 2700;   // 2700K - 6500K
uint8_t redVal = 255;
uint8_t greenVal = 0;
uint8_t blueVal = 255;  // Default to Magenta
uint8_t activeMode = 1; // 0 = CCT, 1 = RGB
bool manualMode =
    false; // true = raw per-channel duties set via serial (calibration)

// Battery telemetry state
uint8_t battPercent = 100; // 0–100, last computed charge level
float battVoltsEMA =
    -1.0f; // exponential moving average of cell voltage (-1 = uninitialized)
unsigned long lastBattMs = 0;

// Connection / advertising lifecycle management.
// Re-advertising must NOT be called directly inside the onDisconnect callback:
// it runs in the BLE stack context where the controller often isn't ready to
// restart advertising yet, so the call silently fails and the device goes
// invisible. Instead we flag it here and restart from loop() after a short
// delay.
volatile bool deviceConnected = false;
volatile bool reAdvertisePending = false;
unsigned long disconnectedAt = 0;
const unsigned long READVERTISE_DELAY_MS = 500;

// User activity controls the idle timer; device and light power are separate.
volatile unsigned long lastActivityMs = 0;

// UUID definitions
#define SERVICE_UUID "E0010000-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_POWER_UUID "E0010001-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_BRIGHT_UUID "E0010002-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_CCT_UUID "E0010003-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_RGB_UUID "E0010004-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_MODE_UUID "E0010005-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_BATT_UUID "E0010006-4B2E-74CA-2C92-41CB5AD2D9BD"

// Battery characteristic pointer (updated + notified from loop())
BLECharacteristic *pCharBatt = nullptr;

void applyDuties() {
  for (int i = 0; i < 5; i++) {
    int pin = PINS[i];
    long d = currentDuties[i];
    if (d > 0) {
      if (!attached[i]) {
        ledcAttach(pin, PWM_FREQ, PWM_RES);
        attached[i] = true;
      }
      ledcWrite(pin, (uint32_t)d);
    } else {
      if (attached[i]) {
        ledcDetach(pin);
        attached[i] = false;
      }
      pinMode(pin, OUTPUT);
      digitalWrite(pin, LOW); // Prevent micro-pulses
    }
  }
}

void report() {
  Serial.printf("Power:%d | Bright8:%3d | Mode:%s | target -> G:%5ld | R:%5ld "
                "| B:%5ld | WW:%5ld | CW:%5ld\n",
                sysPower, brightness8, activeMode == 0 ? "CCT" : "RGB",
                targetDuties[0], targetDuties[1], targetDuties[2],
                targetDuties[3], targetDuties[4]);
}

// ============================================================================
// YUJI RGBWW WHITE MIX — WW<->CW crossfade for the Yuji YJ-BC-HRB-RGBWW5050.
// The strip has two genuine on-locus white channels: WW = 2700 K (GPIO10) and
// CW = 6500 K (GPIO11), Ra 97 / R9 96, Duv ~ -0.001 (Yuji datasheet, see
// old/yuji_rgbww50505/). So tunable white needs NO blue/green/red — just blend
// the two whites. This replaces the old BTF lookup table, which faked high CCTs
// with blue because that strip's cool white topped out near 4540 K.
//
// Intermediate temperatures are interpolated in MIRED (reciprocal-Kelvin) space
// rather than linear Kelvin: equal mired steps are ~perceptually equal, and a
// flux-weighted blend of two whites tracks the Planckian locus far better in
// mired than in Kelvin (a linear-Kelvin 50/50 lands too cool).
// warmFrac+coolFrac sum to 1.0 in software; real flux and chromaticity require
// measurements.
//
// HONESTY NOTE (calibration/README.md working agreement): the two endpoints are
// manufacturer ratings, not measurements of this assembled product.
// Intermediate CCTs are an unmeasured design-intent crossfade. Exact on-locus
// per-unit trim is the Pro Cal Tool's job. Do not relabel this as "validated"
// without a measurement recorded in calibration/.
// ============================================================================
const uint16_t CCT_MIN_K = 2700; // Yuji WW rated white (warm endpoint)
const uint16_t CCT_MAX_K =
    6500; // Yuji CW / daylight rated white (cool endpoint)

// Compute warm/cool white fractions (0..1) for a target CCT (clamped to range).
// warmFrac drives WW, coolFrac drives CW; they sum to 1.0.
void whiteMixFractions(uint16_t t, float &warmFrac, float &coolFrac) {
  if (t < CCT_MIN_K)
    t = CCT_MIN_K;
  if (t > CCT_MAX_K)
    t = CCT_MAX_K;
  const float mWarm = 1000000.0f / (float)CCT_MIN_K; // ~370.4 mired @ 2700 K
  const float mCool = 1000000.0f / (float)CCT_MAX_K; // ~153.8 mired @ 6500 K
  float m = 1000000.0f / (float)t;
  float cool = (mWarm - m) / (mWarm - mCool); // 0 @ 2700 K -> 1 @ 6500 K
  if (cool < 0.0f)
    cool = 0.0f;
  if (cool > 1.0f)
    cool = 1.0f;
  coolFrac = cool;
  warmFrac = 1.0f - cool;
}

void updateLight() {
  // v3: any commanded light change (BLE write, serial cmd, button toggle)
  // funnels through here — it is the single hook that resets the inactivity
  // auto-off timer.
  lastActivityMs = millis();
  if (sysPower == 0 || brightness8 == 0) {
    for (int i = 0; i < 5; i++)
      targetDuties[i] = 0;
  } else if (manualMode) {
    // Manual per-channel calibration mode: targetDuties[] are set directly by
    // the serial X / G R B W C commands as RAW 14-bit duties (no brightness
    // scaling). Leave them untouched here.
  } else if (activeMode == 0) {
    // Tunable white mode (Yuji): WW<->CW crossfade. RGB channels stay OFF; the
    // two white channels carry the entire mix, so chromaticity is preserved as
    // you dim. Brightness uses the same perceptual (exponential) curve as RGB
    // mode, so dimming feels identical in both modes and the low end stays
    // smooth ("beautiful near-darkness").
    float warmFrac, coolFrac;
    whiteMixFractions(cctTemp, warmFrac, coolFrac);
    float normBright = (float)brightness8 / 255.0f;
    float scaler = pow((float)MAXD, normBright - 1.0f);
    targetDuties[0] = 0; // Green off in white mode
    targetDuties[1] = 0; // Red   off in white mode
    targetDuties[2] = 0; // Blue  off in white mode
    targetDuties[3] = lround(warmFrac * (float)MAXD * scaler); // Warm White
    targetDuties[4] = lround(coolFrac * (float)MAXD * scaler); // Cool White
    // Keep a just-visible floor so a non-zero white channel never rounds to
    // OFF.
    if (warmFrac > 0.0f && targetDuties[3] == 0)
      targetDuties[3] = 1;
    if (coolFrac > 0.0f && targetDuties[4] == 0)
      targetDuties[4] = 1;
  } else {
    // RGB Mode
    float normBright = (float)brightness8 / 255.0;
    float scaler = pow((float)MAXD, normBright - 1.0);
    targetDuties[0] =
        round(((float)greenVal / 255.0) * (float)MAXD * scaler); // Green
    targetDuties[1] =
        round(((float)redVal / 255.0) * (float)MAXD * scaler); // Red
    targetDuties[2] =
        round(((float)blueVal / 255.0) * (float)MAXD * scaler); // Blue
    if (greenVal > 0 && targetDuties[0] == 0)
      targetDuties[0] = 1;
    if (redVal > 0 && targetDuties[1] == 0)
      targetDuties[1] = 1;
    if (blueVal > 0 && targetDuties[2] == 0)
      targetDuties[2] = 1;
    targetDuties[3] = 0; // WW
    targetDuties[4] = 0; // CW
  }
  // Bounds check (applies to all paths: off / manual / computed)
  for (int i = 0; i < 5; i++) {
    if (targetDuties[i] < 0)
      targetDuties[i] = 0;
    if (targetDuties[i] > MAXD)
      targetDuties[i] = MAXD;
  }
  report();
}

void rampLight() {
  bool changed = false;
  // Maximum step size per 10ms for smooth 150ms transition (16384 / 15 steps ≈
  // 1092)
  const long RAMP_STEP = 1092;

  for (int i = 0; i < 5; i++) {
    if (currentDuties[i] != targetDuties[i]) {
      long diff = targetDuties[i] - currentDuties[i];
      if (abs(diff) <= RAMP_STEP) {
        currentDuties[i] = targetDuties[i];
      } else {
        if (diff > 0) {
          currentDuties[i] += RAMP_STEP;
        } else {
          currentDuties[i] -= RAMP_STEP;
        }
      }
      changed = true;
    }
  }

  if (changed) {
    applyDuties();
  }
}

#include "battery_telemetry.h"

#include "ble_callbacks.h"

#include "power_control.h"

void setup() {
  // Keep the supply alive before Serial, delays, PWM or BLE initialization.
  initializePowerHardware();
  Serial.begin(115200);
  for (int i = 0; i < 5; i++) {
    pinMode(PINS[i], OUTPUT);
    digitalWrite(PINS[i], LOW);
    attached[i] = false;
    targetDuties[i] = 0;
    currentDuties[i] = 0;
  }
  lastActivityMs = millis();
  Serial.println();
  Serial.println("=== Starting Dark Moth Light BLE Firmware ===");
  Serial.printf("Board: %s | LED pins G:%d R:%d B:%d WW:%d CW:%d\n", BOARD_NAME,
                PINS[0], PINS[1], PINS[2], PINS[3], PINS[4]);
  Serial.printf(
      "Hardware: %s | button active LOW | optical calibration pending\n",
      HARDWARE_REVISION);
  Serial.println("Configuring 2 kHz, 14-bit PWM...");
  updateLight();

  // Initialize BLE
  Serial.println("Starting BLE Device...");
  BLEDevice::init("Dark Moth Light");

  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  // Create Characteristics & Attach Callbacks
  BLECharacteristic *pCharPower = pService->createCharacteristic(
      CHAR_POWER_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharPower->setCallbacks(new PowerCallbacks());
  pCharPower->setValue(&sysPower, 1);

  BLECharacteristic *pCharBright = pService->createCharacteristic(
      CHAR_BRIGHT_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharBright->setCallbacks(new BrightCallbacks());
  pCharBright->setValue(&brightness8, 1);

  BLECharacteristic *pCharCCT = pService->createCharacteristic(
      CHAR_CCT_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharCCT->setCallbacks(new CCTCallbacks());
  uint8_t tempArr[2] = {(uint8_t)(cctTemp >> 8), (uint8_t)(cctTemp & 0xFF)};
  pCharCCT->setValue(tempArr, 2);

  BLECharacteristic *pCharRGB = pService->createCharacteristic(
      CHAR_RGB_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharRGB->setCallbacks(new RGBCallbacks());
  uint8_t rgbArr[3] = {redVal, greenVal, blueVal};
  pCharRGB->setValue(rgbArr, 3);

  BLECharacteristic *pCharMode = pService->createCharacteristic(
      CHAR_MODE_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharMode->setCallbacks(new ModeCallbacks());
  pCharMode->setValue(&activeMode, 1);

  // Battery level: read-only + notify so the app gets live updates (0–100).
  pCharBatt = pService->createCharacteristic(
      CHAR_BATT_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  pCharBatt->addDescriptor(new BLE2902()); // enables client notifications
  // Empty value is ignored by the mobile app and means no telemetry fitted.
  pCharBatt->setValue("");

  // Configure the battery ADC pin (12 dB attenuation → full ~0–3.1 V range).
  if (BATTERY_SENSE_ENABLED)
    analogSetPinAttenuation(PIN_BATT, ADC_11db);
  updateBattery(); // seed an initial reading
  lastBattMs = millis();

  // Start the BLE Service
  pService->start();

  // Configure and start advertising
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06); // Help with connection timing on iOS
  pAdvertising->setMinPreferred(0x12);

  BLEDevice::startAdvertising();
  Serial.println("BLE Advertising successfully started! Ready for connection.");
}

void loop() {
  pollButton(); // v3: power button (short tap = light toggle, long hold = off)

  // --- Read manual controls / serial commands over USB-C ---
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\n' || c == '\r' || c == ' ')
      continue;

    if (c == 'p') {
      long val = Serial.parseInt();
      sysPower = (uint8_t)val;
      manualMode = false;
      updateLight();
    } else if (c == 'b') {
      long val = Serial.parseInt();
      if (val >= 0 && val <= 255) {
        brightness8 = (uint8_t)val;
        manualMode = false;
        updateLight();
      }
    } else if (c == 't') {
      long val = Serial.parseInt();
      if (val < CCT_MIN_K)
        val = CCT_MIN_K; // clamp into the Yuji white range
      if (val > CCT_MAX_K)
        val = CCT_MAX_K;
      cctTemp = (uint16_t)val;
      activeMode = 0; // Switch to CCT mode
      manualMode = false;
      updateLight();
    } else if (c == 'X') {
      // X <G> <R> <B> <WW> <CW> : set all 5 raw 14-bit duties (manual
      // calibration mode)
      long g = Serial.parseInt(), r = Serial.parseInt(), b = Serial.parseInt();
      long w = Serial.parseInt(), cc = Serial.parseInt();
      manualMode = true;
      sysPower = 1;
      targetDuties[0] = g;
      targetDuties[1] = r;
      targetDuties[2] = b;
      targetDuties[3] = w;
      targetDuties[4] = cc;
      updateLight();
    } else if (c == 'G' || c == 'R' || c == 'B' || c == 'W' || c == 'C') {
      // Single channel raw duty, zero the others (manual calibration mode)
      long v = Serial.parseInt();
      int idx = (c == 'G')   ? 0
                : (c == 'R') ? 1
                : (c == 'B') ? 2
                : (c == 'W') ? 3
                             : 4;
      manualMode = true;
      sysPower = 1;
      for (int i = 0; i < 5; i++)
        targetDuties[i] = 0;
      targetDuties[idx] = v;
      updateLight();
    } else if (c == 'Z') {
      // All channels off but stay in manual mode
      manualMode = true;
      sysPower = 1;
      for (int i = 0; i < 5; i++)
        targetDuties[i] = 0;
      updateLight();
    }
  }

  rampLight();

  // Restart advertising on a clean delay after a disconnect, outside the BLE
  // stack callback context. This closes the "device invisible" window that
  // forces the app to retry connecting several times.
  if (reAdvertisePending &&
      (millis() - disconnectedAt >= READVERTISE_DELAY_MS)) {
    reAdvertisePending = false;
    BLEDevice::startAdvertising();
    Serial.println(
        "Advertising restarted after disconnect. Ready for connection.");
  }

  // Periodically re-measure the battery and notify any connected client.
  if (millis() - lastBattMs >= BATT_INTERVAL_MS) {
    lastBattMs = millis();
    updateBattery();
  }

  // v3: auto-power-off after IDLE_OFF_MS, only when the light is off AND no
  // phone is connected (a lit light or a connected app keeps the device awake).
  checkInactivity();

  delay(10); // Run software ramping adjustments every 10ms
}
