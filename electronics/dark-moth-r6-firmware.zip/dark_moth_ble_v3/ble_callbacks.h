#pragma once

// BLE Callbacks
class PowerCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() > 0) {
      sysPower = val[0];
      updateLight();
    }
  }
};

class BrightCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() > 0) {
      brightness8 = val[0];
      updateLight();
    }
  }
};

class CCTCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() >= 2) {
      uint16_t t = (val[0] << 8) | val[1];
      if (t < CCT_MIN_K)
        t = CCT_MIN_K; // clamp into the Yuji white range
      if (t > CCT_MAX_K)
        t = CCT_MAX_K;
      cctTemp = t;
      activeMode = 0; // Switch to CCT mode
      updateLight();
    }
  }
};

class RGBCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() >= 3) {
      redVal = val[0];
      greenVal = val[1];
      blueVal = val[2];
      activeMode = 1; // Switch to RGB mode
      updateLight();
    }
  }
};

class ModeCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() > 0) {
      activeMode = val[0];
      updateLight();
    }
  }
};

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *pServer) {
    deviceConnected = true;
    reAdvertisePending = false;
    lastActivityMs = millis(); // v3: a connection is activity
    Serial.println("BLE Client Connected!");
  }
  void onDisconnect(BLEServer *pServer) {
    deviceConnected = false;
    disconnectedAt = millis();
    lastActivityMs =
        millis(); // v3: start the auto-off clock fresh at disconnect
    reAdvertisePending =
        true; // loop() restarts advertising after a short delay
    Serial.println(
        "BLE Client Disconnected! Scheduling advertising restart...");
  }
};
