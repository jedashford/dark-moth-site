// ============================================================================
// Dark Moth Light - v3 "BUTTON" VARIANT  (Yuji RGBWW build + power button)
// ----------------------------------------------------------------------------
// Isolated prototype copy of firmware/dark_moth_ble. Adds a physical power button
// and a 5-minute auto-power-off via an external push-button power-switch MODULE
// (Adafruit #1400 or Pololu #2808) that gates the board's EN_PWR enable line:
//   * PIN_KILL      -> module KILL/OFF: pulse HIGH to fully power the board down.
//   * PIN_BTN_SENSE <- external momentary button (firmware times taps vs holds).
// "Device power" (the EN_PWR latch) is a SEPARATE layer from "light power"
// (sysPower); the BLE Power characteristic and serial 'p' still mean light-only.
// See v3-button/README.md and v3-button/wiring/wiring.md.
// ----------------------------------------------------------------------------
// Target LED: Yuji YJ-BC-HRB-RGBWW5050 5-in-1 RGBWW strip (Ra 97, R9 96).
//   It has TWO genuine on-locus white channels: WW = 2700 K, CW = 6500 K.
//   Tunable white is therefore a clean WW<->CW crossfade with NO blue mixing
//   (the previous BTF strip needed blue because its cool white maxed ~4540 K;
//   that whole hack is gone — see git history / dark_moth_ble_btf_legacy).
//
// Implements CCT tunable white (2700K - 6500K) and RGB color mixing over
// Bluetooth Low Energy (BLE) at 14-bit / 2 kHz with glitch-free decoupling.
// Features software slew-rate ramping to prevent MCU power sag brownouts.
//
// BLE GATT Specification:
//   Service UUID:         E0010000-4B2E-74CA-2C92-41CB5AD2D9BD
//   Char Power (W/R):     E0010001-4B2E-74CA-2C92-41CB5AD2D9BD (1 byte: 0x00/0x01)
//   Char Brightness(W/R): E0010002-4B2E-74CA-2C92-41CB5AD2D9BD (1 byte: 0x00-0xFF)
//   Char CCT (W/R):       E0010003-4B2E-74CA-2C92-41CB5AD2D9BD (2 bytes: Kelvin)
//   Char RGB (W/R):       E0010004-4B2E-74CA-2C92-41CB5AD2D9BD (3 bytes: R, G, B)
//   Char Mode (W/R):      E0010005-4B2E-74CA-2C92-41CB5AD2D9BD (1 byte: 0x00=CCT, 0x01=RGB)
//   Char Battery(R/N):    E0010006-4B2E-74CA-2C92-41CB5AD2D9BD (3 bytes: percent, mV_hi, mV_lo)
//                         Byte 0 = charge percent (0-100). Bytes 1-2 = cell
//                         millivolts (big-endian uint16). A client that only
//                         reads byte 0 still works — voltage is appended, not
//                         repositioned.
// ============================================================================

#include "button_sense.h"
#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEServer.h>
#include <BLE2902.h>

// ----------------------------------------------------------------------------
// LED channel -> GPIO mapping. ONE firmware, both boards: the correct pins are
// selected automatically from the chip you compile for (the esp32 core defines
// CONFIG_IDF_TARGET_*). Battery sense is GPIO1 on both.
//   ESP32-S3:  Green=5, Red=4,  Blue=6,  WW=10, CW=11
//   ESP32-C3:  Green=5, Red=6,  Blue=7,  WW=10, CW=20
//     C3 caveats: avoid GPIO 8/9 (strapping + BOOT — a MOSFET gate pull-down
//     there forces download mode at power-up), GPIO 11-17 (SPI flash), 18/19
//     (USB). GPIO 20/21 are UART0 but free because the console is USB-CDC.
// To flash:
//   S3:  arduino-cli upload -p <port> --fqbn esp32:esp32:esp32s3:USBMode=hwcdc,CDCOnBoot=cdc firmware/dark_moth_ble
//   C3:  arduino-cli upload -p <port> --fqbn esp32:esp32:esp32c3:CDCOnBoot=cdc            firmware/dark_moth_ble
// ----------------------------------------------------------------------------
#if defined(CONFIG_IDF_TARGET_ESP32C3)
  const int   PINS[5]  = { 5, 6, 7, 10, 20 };   // C3: G, R, B, WW, CW
  #define BOARD_NAME "ESP32-C3"
#elif defined(CONFIG_IDF_TARGET_ESP32S3)
  const int   PINS[5]  = { 5, 4, 6, 10, 11 };   // S3: G, R, B, WW, CW
  #define BOARD_NAME "ESP32-S3"
#else
  #error "Unsupported target: add a PINS[] mapping for this chip (avoid strapping/flash/USB pins)."
#endif
const char* NAMES[5] = { "Green", "Red", "Blue", "Warm White", "Cool White" };
const int   PWM_FREQ = 2000;
const int   PWM_RES  = 14;

// ----------------------------------------------------------------------------
// v3 POWER-BUTTON pins + control style. Two builds are supported (POWER_LATCH_DISCRETE):
//   PIN_KILL      -> device-power control line to the latch:
//                      DISCRETE on-hand build : it HOLDS power — HIGH = stay on, LOW = off.
//                      MODULE (#1400 / #2808) : it is KILL — pulse HIGH = off, idle LOW.
//   PIN_BTN_SENSE <- the momentary button:
//                      DISCRETE: 100k/100k divider, analog voltage with hysteresis.
//                      MODULE  : button to GND, pressed = LOW (INPUT_PULLUP).
// C3 (PRIMARY build): latch=GPIO3, sense=GPIO4 — GPIO 2/8/9 are strapping/BOOT
// on the C3 (the latch pulldown on 9 would force download mode), so the button
// circuit must avoid them. Matches wiring/dark_moth_v3_button_wiring_c3.*.
// S3 (alternate): borrows the unused J4 cal pads (SDA=8, SCL=9) — free there.
// ----------------------------------------------------------------------------
#if defined(CONFIG_IDF_TARGET_ESP32C3)
  const int PIN_KILL      = 3;   // power latch hold/kill (C3: 8/9 are strapping — do not move there)
  const int PIN_BTN_SENSE = 4;   // button sense divider
#else // ESP32-S3 (alternate board): J4 cal header pads
  const int PIN_KILL      = 9;   // J4 SCL pad -> power latch hold/kill
  const int PIN_BTN_SENSE = 8;   // J4 SDA pad <- button sense
#endif

// Power-control style. The chosen on-hand build
// (v3-button/wiring/dark_moth_v3_button_wiring_{c3,s3}.*) is a DISCRETE soft-latch: PIN_KILL
// holds the SS8550 + BS170 latch on (HIGH); dropping it LOW releases the latch and powers the
// board off.
// Set 0 for the buy-a-module path (Adafruit #1400 / Pololu #2808), where the line is KILL.
#define POWER_LATCH_DISCRETE 1
#if POWER_LATCH_DISCRETE
  #define PWR_HOLD_LEVEL  HIGH   // drive the latch pin HIGH to KEEP power on
  #define PWR_OFF_LEVEL   LOW    // drive LOW to release the latch -> board powers off
  #define BTN_PIN_MODE    INPUT  // divider sets the level; do NOT enable an internal pullup
#else
  #define PWR_HOLD_LEVEL  LOW    // module: KILL idle LOW
  #define PWR_OFF_LEVEL   HIGH   // module: pulse KILL HIGH to power off
  #define BTN_PIN_MODE    INPUT_PULLUP
#endif

// ----------------------------------------------------------------------------
// BATTERY SENSE (1S LiPo, 3.0–4.2 V)
// R5 omits the optional divider: an always-live B+ divider can feed an unpowered GPIO.
// Enable only after verifying an isolated measurement circuit and calibration.
#ifndef BATTERY_SENSE_ENABLED
#define BATTERY_SENSE_ENABLED 0
#endif
// When enabled, the external 100k/100k divider feeds GPIO1.
// The divider halves the cell, so 4.2 V reads ~2.1 V at the pin (safe < 3.3 V).
// analogReadMilliVolts() returns the factory-calibrated pin voltage in mV; we
// multiply by the divider ratio (2.0) and a per-unit trim to recover the cell V.
// ----------------------------------------------------------------------------
const int    PIN_BATT       = 1;       // GPIO1 = ADC1 (CH1 on ESP32-C3 / CH0 on S3)
const float  BATT_DIVIDER   = 2.0f;    // (R1 + R2) / R2 = (100k + 100k) / 100k
const float  BATT_CAL       = 1.0f;    // per-unit trim: measure cell w/ DMM, set = Vreal / Vreported
const int    BATT_SAMPLES   = 16;      // ADC reads averaged per measurement
const unsigned long BATT_INTERVAL_MS = 5000; // how often to re-measure + notify

// ----------------------------------------------------------------------------
// MAXD Ceiling Rationale (16380 vs 16383 vs 16384):
// At 14-bit resolution, the theoretical full duty cycle is 2^14 = 16384.
// - Writing 16384 triggers an internal driver overflow / boundary check failure
//   in Arduino-ESP32 v3.x core's ledcWrite, which drops the duty cycle to 0% (OFF).
// - Writing 16383 (2^14-1) works on RGB channels (0-2), but triggers a hardware comparison
//   latching glitch in the ESP32-S3 registers on channels 3 & 4 (GPIO 10 & 11, CCT),
//   causing the white channels to shut off completely at 100% brightness.
// - Capping MAXD at 16380 (99.97% duty) avoids both driver and hardware glitches
//   on all channels, ensuring solid and stable full output that is visually
//   indistinguishable from absolute 100% brightness.
// ----------------------------------------------------------------------------
const long  MAXD     = 16380;

// Active state
long targetDuties[5]  = {0, 0, 0, 0, 0};
long currentDuties[5] = {0, 0, 0, 0, 0};
bool attached[5]      = {false, false, false, false, false};

// Control variables (BLE state)
uint8_t sysPower    = 0;   // 0 = Off, 1 = On (Starts OFF by default)
uint8_t brightness8 = 127; // 0 - 255 (defaults to 50%)
uint16_t cctTemp    = 2700; // 2700K - 6500K
uint8_t redVal      = 255;
uint8_t greenVal    = 0;
uint8_t blueVal     = 255; // Default to Magenta
uint8_t activeMode  = 1;   // 0 = CCT, 1 = RGB
bool    manualMode  = false; // true = raw per-channel duties set via serial (calibration)

// Battery telemetry state
uint8_t  battPercent     = 100;  // 0–100, last computed charge level
float    battVoltsEMA    = -1.0f; // exponential moving average of cell voltage (-1 = uninitialized)
unsigned long lastBattMs = 0;

// Connection / advertising lifecycle management.
// Re-advertising must NOT be called directly inside the onDisconnect callback:
// it runs in the BLE stack context where the controller often isn't ready to
// restart advertising yet, so the call silently fails and the device goes
// invisible. Instead we flag it here and restart from loop() after a short delay.
volatile bool deviceConnected     = false;
volatile bool reAdvertisePending  = false;
unsigned long disconnectedAt      = 0;
const unsigned long READVERTISE_DELAY_MS = 500;

// ----------------------------------------------------------------------------
// v3 POWER-BUTTON / AUTO-OFF tunables + state.
// Device power (the EN_PWR latch, via the external module) is a separate layer
// from light power (sysPower). The button is the ONLY control of device power.
// ----------------------------------------------------------------------------
const bool          BTN_ACTIVE_LOW   = !POWER_LATCH_DISCRETE; // discrete divider = active-HIGH; module to-GND = active-LOW
const unsigned long DEBOUNCE_MS      = 30;
const unsigned long SHORTTAP_MAX_MS  = 500;              // <= this released = short tap
const unsigned long LONGPRESS_OFF_MS = 2000;             // >= this held = power off
const unsigned long CONFIRM_ON_MS    = 1000;             // hold-to-confirm power-on
const unsigned long IDLE_OFF_MS      = 5UL * 60UL * 1000UL; // 5-min idle auto-off

// Short tap toggles the LIGHT (light off, device stays on/connectable).
// Set 0 for a pure hold-only button.
#define BTN_SHORT_TOGGLES_LIGHT 1

// Require the button HELD ~1 s at boot or the device powers back off (anti-pocket).
// STAGE B ONLY: enable only once PIN_BTN_SENSE is wired, else it powers off at boot.
#define REQUIRE_HOLD_TO_CONFIRM_ON 0

// Activity + debounce state
volatile unsigned long lastActivityMs = 0;   // reset by any user action
int           btnStableLevel  = HIGH;        // debounced level
int           btnLastRaw      = HIGH;
unsigned long btnLastChangeMs = 0;
bool          btnIsDown       = false;
unsigned long btnPressStartMs = 0;
bool          longPressFired  = false;       // one power-off per long hold

// UUID definitions
#define SERVICE_UUID           "E0010000-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_POWER_UUID        "E0010001-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_BRIGHT_UUID       "E0010002-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_CCT_UUID          "E0010003-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_RGB_UUID          "E0010004-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_MODE_UUID         "E0010005-4B2E-74CA-2C92-41CB5AD2D9BD"
#define CHAR_BATT_UUID         "E0010006-4B2E-74CA-2C92-41CB5AD2D9BD"

// Battery characteristic pointer (updated + notified from loop())
BLECharacteristic *pCharBatt = nullptr;

void applyDuties() {
  for (int i = 0; i < 5; i++) {
    int pin = PINS[i];
    long d = currentDuties[i];
    if (d > 0) {
      if (!attached[i]) {
        ledcAttach(pin, PWM_FREQ, PWM_RES);
        attached[i] = true;
      }
      ledcWrite(pin, (uint32_t)d);
    } else {
      if (attached[i]) {
        ledcDetach(pin);
        attached[i] = false;
      }
      pinMode(pin, OUTPUT);
      digitalWrite(pin, LOW); // Prevent micro-pulses
    }
  }
}

void report() {
  Serial.printf("Power:%d | Bright8:%3d | Mode:%s | target -> G:%5ld | R:%5ld | B:%5ld | WW:%5ld | CW:%5ld\n",
                sysPower, brightness8, activeMode == 0 ? "CCT" : "RGB",
                targetDuties[0], targetDuties[1], targetDuties[2], targetDuties[3], targetDuties[4]);
}

// ============================================================================
// YUJI RGBWW WHITE MIX — WW<->CW crossfade for the Yuji YJ-BC-HRB-RGBWW5050.
// The strip has two genuine on-locus white channels: WW = 2700 K (GPIO10) and
// CW = 6500 K (GPIO11), Ra 97 / R9 96, Duv ~ -0.001 (Yuji datasheet, see
// old/yuji_rgbww50505/). So tunable white needs NO blue/green/red — just blend
// the two whites. This replaces the old BTF lookup table, which faked high CCTs
// with blue because that strip's cool white topped out near 4540 K.
//
// Intermediate temperatures are interpolated in MIRED (reciprocal-Kelvin) space
// rather than linear Kelvin: equal mired steps are ~perceptually equal, and a
// flux-weighted blend of two whites tracks the Planckian locus far better in
// mired than in Kelvin (a linear-Kelvin 50/50 lands too cool). warmFrac+coolFrac
// always sum to 1.0, so total white flux stays ~constant across the sweep.
//
// HONESTY NOTE (calibration/README.md working agreement): only the two ENDPOINTS
// are spectrometer-grade truths — they ARE the LED's rated whites (WW-only /
// CW-only). Intermediate CCTs are a DESIGN-INTENT crossfade, NOT yet measured on
// this strip. Exact on-locus per-unit trim is the Pro Cal Tool's job. Do not
// relabel this as "validated" without a measurement recorded in calibration/.
// ============================================================================
const uint16_t CCT_MIN_K = 2700;   // Yuji WW rated white (warm endpoint)
const uint16_t CCT_MAX_K = 6500;   // Yuji CW / daylight rated white (cool endpoint)

// Compute warm/cool white fractions (0..1) for a target CCT (clamped to range).
// warmFrac drives WW, coolFrac drives CW; they sum to 1.0.
void whiteMixFractions(uint16_t t, float &warmFrac, float &coolFrac) {
  if (t < CCT_MIN_K) t = CCT_MIN_K;
  if (t > CCT_MAX_K) t = CCT_MAX_K;
  const float mWarm = 1000000.0f / (float)CCT_MIN_K;  // ~370.4 mired @ 2700 K
  const float mCool = 1000000.0f / (float)CCT_MAX_K;  // ~153.8 mired @ 6500 K
  float m = 1000000.0f / (float)t;
  float cool = (mWarm - m) / (mWarm - mCool);         // 0 @ 2700 K -> 1 @ 6500 K
  if (cool < 0.0f) cool = 0.0f;
  if (cool > 1.0f) cool = 1.0f;
  coolFrac = cool;
  warmFrac = 1.0f - cool;
}

void updateLight() {
  // v3: any commanded light change (BLE write, serial cmd, button toggle) funnels
  // through here — it is the single hook that resets the inactivity auto-off timer.
  lastActivityMs = millis();
  if (sysPower == 0 || brightness8 == 0) {
    for (int i = 0; i < 5; i++) targetDuties[i] = 0;
  } else if (manualMode) {
    // Manual per-channel calibration mode: targetDuties[] are set directly by the
    // serial X / G R B W C commands as RAW 14-bit duties (no brightness scaling).
    // Leave them untouched here.
  } else if (activeMode == 0) {
    // Tunable white mode (Yuji): WW<->CW crossfade. RGB channels stay OFF; the
    // two white channels carry the entire mix, so chromaticity is preserved as
    // you dim. Brightness uses the same perceptual (exponential) curve as RGB
    // mode, so dimming feels identical in both modes and the low end stays
    // smooth ("beautiful near-darkness").
    float warmFrac, coolFrac;
    whiteMixFractions(cctTemp, warmFrac, coolFrac);
    float normBright = (float)brightness8 / 255.0f;
    float scaler     = pow((float)MAXD, normBright - 1.0f);
    targetDuties[0] = 0;  // Green off in white mode
    targetDuties[1] = 0;  // Red   off in white mode
    targetDuties[2] = 0;  // Blue  off in white mode
    targetDuties[3] = lround(warmFrac * (float)MAXD * scaler);  // Warm White
    targetDuties[4] = lround(coolFrac * (float)MAXD * scaler);  // Cool White
    // Keep a just-visible floor so a non-zero white channel never rounds to OFF.
    if (warmFrac > 0.0f && targetDuties[3] == 0) targetDuties[3] = 1;
    if (coolFrac > 0.0f && targetDuties[4] == 0) targetDuties[4] = 1;
  } else {
    // RGB Mode
    float normBright = (float)brightness8 / 255.0;
    float scaler = pow((float)MAXD, normBright - 1.0);
    targetDuties[0] = round(((float)greenVal / 255.0) * (float)MAXD * scaler); // Green
    targetDuties[1] = round(((float)redVal   / 255.0) * (float)MAXD * scaler); // Red
    targetDuties[2] = round(((float)blueVal  / 255.0) * (float)MAXD * scaler); // Blue
    if (greenVal > 0 && targetDuties[0] == 0) targetDuties[0] = 1;
    if (redVal   > 0 && targetDuties[1] == 0) targetDuties[1] = 1;
    if (blueVal  > 0 && targetDuties[2] == 0) targetDuties[2] = 1;
    targetDuties[3] = 0; // WW
    targetDuties[4] = 0; // CW
  }
  // Bounds check (applies to all paths: off / manual / computed)
  for (int i = 0; i < 5; i++) {
    if (targetDuties[i] < 0) targetDuties[i] = 0;
    if (targetDuties[i] > MAXD) targetDuties[i] = MAXD;
  }
  report();
}

void rampLight() {
  bool changed = false;
  // Maximum step size per 10ms for smooth 150ms transition (16384 / 15 steps ≈ 1092)
  const long RAMP_STEP = 1092; 
  
  for (int i = 0; i < 5; i++) {
    if (currentDuties[i] != targetDuties[i]) {
      long diff = targetDuties[i] - currentDuties[i];
      if (abs(diff) <= RAMP_STEP) {
        currentDuties[i] = targetDuties[i];
      } else {
        if (diff > 0) {
          currentDuties[i] += RAMP_STEP;
        } else {
          currentDuties[i] -= RAMP_STEP;
        }
      }
      changed = true;
    }
  }
  
  if (changed) {
    applyDuties();
  }
}

// ----------------------------------------------------------------------------
// Battery: read the divider, recover cell voltage, map to a LiPo % curve.
// ----------------------------------------------------------------------------

// Average several ADC reads and convert back to the true cell voltage.
float readBatteryVolts() {
  uint32_t accum_mV = 0;
  for (int i = 0; i < BATT_SAMPLES; i++) {
    accum_mV += analogReadMilliVolts(PIN_BATT);
  }
  float pin_mV = (float)accum_mV / (float)BATT_SAMPLES;
  return (pin_mV / 1000.0f) * BATT_DIVIDER * BATT_CAL; // volts at the cell
}

// Resting-discharge curve for a 1S LiPo. Piecewise-linear between table points.
// Voltage is under light load; the EMA smooths out PWM-induced rail dips.
uint8_t voltageToPercent(float v) {
  static const float vTab[] = {3.30f, 3.50f, 3.61f, 3.69f, 3.71f, 3.73f, 3.75f,
                               3.77f, 3.79f, 3.80f, 3.82f, 3.84f, 3.87f, 3.91f,
                               3.95f, 3.98f, 4.02f, 4.08f, 4.11f, 4.15f, 4.20f};
  static const float pTab[] = {0,    5,     10,    15,    20,    25,    30,
                               35,    40,    45,    50,    55,    60,    65,
                               70,    75,    80,    85,    90,    95,    100};
  const int n = sizeof(vTab) / sizeof(vTab[0]);

  if (v <= vTab[0])     return 0;
  if (v >= vTab[n - 1]) return 100;
  for (int i = 0; i < n - 1; i++) {
    if (v < vTab[i + 1]) {
      float frac = (v - vTab[i]) / (vTab[i + 1] - vTab[i]);
      return (uint8_t)round(pTab[i] + frac * (pTab[i + 1] - pTab[i]));
    }
  }
  return 100;
}

// Measure, smooth, recompute percent, and push a BLE notify if connected.
void updateBattery() {
  if (!BATTERY_SENSE_ENABLED) return; // Empty BLE value means unavailable; no floating ADC reads.
  float v = readBatteryVolts();
  // Initialize or update the exponential moving average (alpha = 0.25).
  battVoltsEMA = (battVoltsEMA < 0.0f) ? v : (battVoltsEMA + 0.25f * (v - battVoltsEMA));
  battPercent  = voltageToPercent(battVoltsEMA);

  if (pCharBatt != nullptr) {
    // Pack [percent, mV_hi, mV_lo]. Clamp mV to a uint16 so the cast is safe.
    long mV = lround(battVoltsEMA * 1000.0f);
    if (mV < 0)     mV = 0;
    if (mV > 65535) mV = 65535;
    uint8_t payload[3] = { battPercent, (uint8_t)(mV >> 8), (uint8_t)(mV & 0xFF) };
    pCharBatt->setValue(payload, 3);
    if (deviceConnected) pCharBatt->notify();
  }
  Serial.printf("Battery: %.3f V (cell) -> %u%%\n", battVoltsEMA, battPercent);
}

// BLE Callbacks
class PowerCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() > 0) {
      sysPower = val[0];
      updateLight();
    }
  }
};

class BrightCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() > 0) {
      brightness8 = val[0];
      updateLight();
    }
  }
};

class CCTCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() >= 2) {
      uint16_t t = (val[0] << 8) | val[1];
      if (t < CCT_MIN_K) t = CCT_MIN_K;   // clamp into the Yuji white range
      if (t > CCT_MAX_K) t = CCT_MAX_K;
      cctTemp = t;
      activeMode = 0; // Switch to CCT mode
      updateLight();
    }
  }
};

class RGBCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() >= 3) {
      redVal = val[0];
      greenVal = val[1];
      blueVal = val[2];
      activeMode = 1; // Switch to RGB mode
      updateLight();
    }
  }
};

class ModeCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String val = pCharacteristic->getValue();
    if (val.length() > 0) {
      activeMode = val[0];
      updateLight();
    }
  }
};

class ServerCallbacks: public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    deviceConnected = true;
    reAdvertisePending = false;
    lastActivityMs = millis();   // v3: a connection is activity
    Serial.println("BLE Client Connected!");
  }
  void onDisconnect(BLEServer* pServer) {
    deviceConnected = false;
    disconnectedAt = millis();
    lastActivityMs = millis();   // v3: start the auto-off clock fresh at disconnect
    reAdvertisePending = true;  // loop() restarts advertising after a short delay
    Serial.println("BLE Client Disconnected! Scheduling advertising restart...");
  }
};

// ============================================================================
// v3 POWER-BUTTON / AUTO-OFF helpers
//   Device power is gated by the v3 power latch (discrete SS8550 + BS170, or a module).
//   We drive PIN_KILL to release that latch and power the board fully off, and read the
//   button on PIN_BTN_SENSE to time short taps vs long holds.
// ============================================================================
// Convert the discrete divider to a stable logical level for existing gesture handling.
int readButtonLevel() {
#if POWER_LATCH_DISCRETE
  static bool pressed = false;
  uint32_t totalMillivolts = 0;
  for (int i = 0; i < 4; ++i) totalMillivolts += analogReadMilliVolts(PIN_BTN_SENSE);
  pressed = discreteButtonPressed(totalMillivolts / 4, pressed);
  return pressed ? HIGH : LOW;
#else
  return digitalRead(PIN_BTN_SENSE);
#endif
}

inline bool btnPressed(int rawLevel) {
  return BTN_ACTIVE_LOW ? (rawLevel == LOW) : (rawLevel == HIGH);
}

// True when no light is being emitted — used to gate the inactivity auto-off.
bool lightIsOff() {
  if (sysPower == 0) return true;
  for (int i = 0; i < 5; i++) if (targetDuties[i] > 0) return false;
  return true;
}

// Brief "powering off" cue: flash Red twice on the raw gate, independent of the
// PWM/duty state. Reuses the LED hardware, so no extra parts are needed.
void ledFeedbackBlink() {
  int pin = PINS[1]; // Red channel
  if (attached[1]) { ledcDetach(pin); attached[1] = false; }
  pinMode(pin, OUTPUT);
  for (int k = 0; k < 2; k++) {
    digitalWrite(pin, HIGH); delay(60);
    digitalWrite(pin, LOW);  delay(80);
  }
}

// Fully power the device off via the device-power latch (PIN_KILL).
//   DISCRETE build: drive the latch LOW -> SS8550 + BS170 release -> the rail collapses HERE
//                   and the MCU stops mid-function.
//   MODULE build  : pulse KILL HIGH.
// If the latch is NOT wired (pure firmware bench test on USB) the rail does not actually drop,
// so we restore the HOLD level after a moment and keep the board usable.
void powerOff(const char *reason) {
  Serial.printf("[powerOff] %s -> releasing power latch\n", reason ? reason : "");
  sysPower = 0;
  manualMode = false;
  updateLight();                 // zero all targets
  for (int i = 0; i < 5; i++) currentDuties[i] = 0;
  applyDuties();                 // LEDs off immediately (no ramp)
  ledFeedbackBlink();            // user cue
  Serial.flush();
  pinMode(PIN_KILL, OUTPUT);
  digitalWrite(PIN_KILL, PWR_OFF_LEVEL);   // real HW: rail dies HERE
  delay(1500);                             // only reached if the latch is not wired (USB bench)
  digitalWrite(PIN_KILL, PWR_HOLD_LEVEL);  // restore HOLD so a USB-bench board keeps running
  Serial.println("[powerOff] still powered (latch not wired?) — resuming.");
  lastActivityMs = millis();     // avoid immediately re-triggering auto-off
}

// Non-blocking, debounced button poll. Short tap toggles the light; a long hold powers the
// device fully off. DISCRETE latch: the long-hold is detected mid-press (prompt LED cue) but
// the actual power-off happens on RELEASE — a still-held button would re-trigger the cold-start
// path and bounce the board back on. MODULE: KILL overrides a held button, so it powers off
// mid-hold (no release race).
void pollButton() {
  unsigned long now = millis();
  int raw = readButtonLevel();
  if (raw != btnLastRaw) { btnLastRaw = raw; btnLastChangeMs = now; }
  if ((now - btnLastChangeMs) >= DEBOUNCE_MS && raw != btnStableLevel) {
    btnStableLevel = raw;
    if (btnPressed(raw)) {
      btnIsDown = true;
      btnPressStartMs = now;
      longPressFired = false;
      lastActivityMs = now;
    } else if (btnIsDown) {
      unsigned long held = now - btnPressStartMs;
      btnIsDown = false;
      lastActivityMs = now;
      if (longPressFired) {
#if POWER_LATCH_DISCRETE
        powerOff("button long-press (released)"); // discrete: power off on release
#endif
      } else if (held <= SHORTTAP_MAX_MS) {
#if BTN_SHORT_TOGGLES_LIGHT
        sysPower = sysPower ? 0 : 1;
        manualMode = false;
        updateLight();
#endif
      }
    }
  }
  if (btnIsDown && !longPressFired && (now - btnPressStartMs) >= LONGPRESS_OFF_MS) {
    longPressFired = true;
#if POWER_LATCH_DISCRETE
    ledFeedbackBlink();             // cue now; actually power off on release (above)
#else
    powerOff("button long-press");  // module KILL overrides a held button — off immediately
#endif
  }
}

// Inactivity auto-off: only when the light is OFF and no phone is connected.
void checkInactivity() {
  if (!lightIsOff()) return;       // never power off a lit light
  if (deviceConnected) return;     // a connected app keeps it awake
  if ((millis() - lastActivityMs) >= IDLE_OFF_MS) {
    powerOff("5-min inactivity");
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  
  // Hard LOW standard GPIO initially
  for (int i = 0; i < 5; i++) {
    pinMode(PINS[i], OUTPUT);
    digitalWrite(PINS[i], LOW);
    attached[i] = false;
    targetDuties[i] = 0;
    currentDuties[i] = 0;
  }

  // v3 power-button: assert the device-power HOLD immediately so a discrete latch keeps the
  // rail up the instant firmware runs (HIGH = hold for the discrete build; for the module
  // build this idles KILL LOW — same line, inverted meaning). Button uses the build's sense
  // mode. lastActivityMs starts the auto-off clock.
  pinMode(PIN_KILL, OUTPUT);
  digitalWrite(PIN_KILL, PWR_HOLD_LEVEL);
  pinMode(PIN_BTN_SENSE, BTN_PIN_MODE);
  analogReadResolution(12);
#if POWER_LATCH_DISCRETE
  // Must precede both the boot confirmation loop and normal gesture reads.
  analogSetPinAttenuation(PIN_BTN_SENSE, ADC_11db);
#endif
  lastActivityMs = millis();
#if REQUIRE_HOLD_TO_CONFIRM_ON
  // Anti-pocket: require the button HELD ~CONFIRM_ON_MS at boot, else power off.
  // STAGE B ONLY — needs PIN_BTN_SENSE wired, or the device powers off every boot.
  {
    unsigned long t0 = millis();
    bool held = true;
    while (millis() - t0 < CONFIRM_ON_MS) {
      if (!btnPressed(readButtonLevel())) { held = false; break; }
      delay(10);
    }
    if (!held) powerOff("power-on not confirmed");
  }
#endif

  Serial.println();
  Serial.println("=== Starting Dark Moth Light BLE Firmware ===");
  Serial.printf("Board: %s | LED pins G:%d R:%d B:%d WW:%d CW:%d\n",
                BOARD_NAME, PINS[0], PINS[1], PINS[2], PINS[3], PINS[4]);
  Serial.println("Configuring 2 kHz, 14-bit glitch-free driver...");
  updateLight();
  
  // Initialize BLE
  Serial.println("Starting BLE Device...");
  BLEDevice::init("Dark Moth Light");
  
  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());
  
  BLEService *pService = pServer->createService(SERVICE_UUID);
  
  // Create Characteristics & Attach Callbacks
  BLECharacteristic *pCharPower = pService->createCharacteristic(CHAR_POWER_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharPower->setCallbacks(new PowerCallbacks());
  pCharPower->setValue(&sysPower, 1);
  
  BLECharacteristic *pCharBright = pService->createCharacteristic(CHAR_BRIGHT_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharBright->setCallbacks(new BrightCallbacks());
  pCharBright->setValue(&brightness8, 1);
  
  BLECharacteristic *pCharCCT = pService->createCharacteristic(CHAR_CCT_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharCCT->setCallbacks(new CCTCallbacks());
  uint8_t tempArr[2] = { (uint8_t)(cctTemp >> 8), (uint8_t)(cctTemp & 0xFF) };
  pCharCCT->setValue(tempArr, 2);
  
  BLECharacteristic *pCharRGB = pService->createCharacteristic(CHAR_RGB_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharRGB->setCallbacks(new RGBCallbacks());
  uint8_t rgbArr[3] = { redVal, greenVal, blueVal };
  pCharRGB->setValue(rgbArr, 3);
  
  BLECharacteristic *pCharMode = pService->createCharacteristic(CHAR_MODE_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE);
  pCharMode->setCallbacks(new ModeCallbacks());
  pCharMode->setValue(&activeMode, 1);

  // Battery level: read-only + notify so the app gets live updates (0–100).
  pCharBatt = pService->createCharacteristic(CHAR_BATT_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  pCharBatt->addDescriptor(new BLE2902());           // enables client notifications
  // Empty value is ignored by the mobile app and means no telemetry fitted.
  pCharBatt->setValue("");

  // Configure the battery ADC pin (12 dB attenuation → full ~0–3.1 V range).
  if (BATTERY_SENSE_ENABLED) analogSetPinAttenuation(PIN_BATT, ADC_11db);
  updateBattery();                                    // seed an initial reading
  lastBattMs = millis();

  // Start the BLE Service
  pService->start();
  
  // Configure and start advertising
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);  // Help with connection timing on iOS
  pAdvertising->setMinPreferred(0x12);
  
  BLEDevice::startAdvertising();
  Serial.println("BLE Advertising successfully started! Ready for connection.");
}

void loop() {
  pollButton();      // v3: power button (short tap = light toggle, long hold = off)

  // --- Read manual controls / serial commands over USB-C ---
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\n' || c == '\r' || c == ' ') continue;
    
    if (c == 'p') {
      long val = Serial.parseInt();
      sysPower = (uint8_t)val;
      manualMode = false;
      updateLight();
    } else if (c == 'b') {
      long val = Serial.parseInt();
      if (val >= 0 && val <= 255) {
        brightness8 = (uint8_t)val;
        manualMode = false;
        updateLight();
      }
    } else if (c == 't') {
      long val = Serial.parseInt();
      if (val < CCT_MIN_K) val = CCT_MIN_K;   // clamp into the Yuji white range
      if (val > CCT_MAX_K) val = CCT_MAX_K;
      cctTemp = (uint16_t)val;
      activeMode = 0; // Switch to CCT mode
      manualMode = false;
      updateLight();
    } else if (c == 'X') {
      // X <G> <R> <B> <WW> <CW> : set all 5 raw 14-bit duties (manual calibration mode)
      long g = Serial.parseInt(), r = Serial.parseInt(), b = Serial.parseInt();
      long w = Serial.parseInt(), cc = Serial.parseInt();
      manualMode = true; sysPower = 1;
      targetDuties[0] = g; targetDuties[1] = r; targetDuties[2] = b;
      targetDuties[3] = w; targetDuties[4] = cc;
      updateLight();
    } else if (c == 'G' || c == 'R' || c == 'B' || c == 'W' || c == 'C') {
      // Single channel raw duty, zero the others (manual calibration mode)
      long v = Serial.parseInt();
      int idx = (c == 'G') ? 0 : (c == 'R') ? 1 : (c == 'B') ? 2 : (c == 'W') ? 3 : 4;
      manualMode = true; sysPower = 1;
      for (int i = 0; i < 5; i++) targetDuties[i] = 0;
      targetDuties[idx] = v;
      updateLight();
    } else if (c == 'Z') {
      // All channels off but stay in manual mode
      manualMode = true; sysPower = 1;
      for (int i = 0; i < 5; i++) targetDuties[i] = 0;
      updateLight();
    }
  }

  rampLight();

  // Restart advertising on a clean delay after a disconnect, outside the BLE
  // stack callback context. This closes the "device invisible" window that
  // forces the app to retry connecting several times.
  if (reAdvertisePending && (millis() - disconnectedAt >= READVERTISE_DELAY_MS)) {
    reAdvertisePending = false;
    BLEDevice::startAdvertising();
    Serial.println("Advertising restarted after disconnect. Ready for connection.");
  }

  // Periodically re-measure the battery and notify any connected client.
  if (millis() - lastBattMs >= BATT_INTERVAL_MS) {
    lastBattMs = millis();
    updateBattery();
  }

  // v3: auto-power-off after IDLE_OFF_MS, only when the light is off AND no phone
  // is connected (a lit light or a connected app keeps the device awake).
  checkInactivity();

  delay(10); // Run software ramping adjustments every 10ms
}
