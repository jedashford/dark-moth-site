#pragma once
#include <stdint.h>

// R5 discrete board: 100k / 100k gives ~1500-2100 mV while pressed.
// Hysteresis tolerates ADC noise. GPIO digital VIH is not guaranteed at 2.1 V.
inline bool discreteButtonPressed(uint32_t millivolts, bool previouslyPressed) {
  constexpr uint32_t pressMillivolts = 1000;
  constexpr uint32_t releaseMillivolts = 500;
  return previouslyPressed ? millivolts > releaseMillivolts
                           : millivolts >= pressMillivolts;
}
